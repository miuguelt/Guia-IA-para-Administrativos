# Laboratorio: clima

Descomprime el paquete completo y abre [LEEME.html](LEEME.html). Allí están los encargos para chat e IDE, las fuentes y los modelos de salida.

Estos son datos públicos reales de fuentes oficiales. Las fuentes, los filtros y las condiciones de uso acompañan los archivos.

La guía describe cinco casos. Sus cinco paquetes de IA, encargos, esquemas y fuentes enlazadas se incluyen en ia/; no necesitas la guía web para abrirlos.

Los cuatro conjuntos básicos se incluyen juntos para que la validación del cuaderno funcione sin red. Los originales se conservan separados. Para empezar, entrega el encargo y las fuentes a la IA. El agente puede repetir el análisis con Python 3.11 o superior mediante `python codigo/analysis_data.py validar` y `python codigo/analysis_data.py analizar`. Las figuras requieren Matplotlib; la ampliación DANE usa openpyxl. Puedes instalar ambos con `python -m pip install matplotlib==3.11.0 openpyxl==3.1.5`. Los cuadernos/ permiten que el agente conserve la ejecución por etapas. Las acciones refrescar y refrescar-dane descargan una nueva versión; no las necesitas para esta práctica.
