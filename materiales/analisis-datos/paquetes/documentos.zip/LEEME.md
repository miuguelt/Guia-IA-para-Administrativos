# Laboratorio: documentos

Descomprime el paquete completo y abre [LEEME.html](LEEME.html). Allí están los encargos para chat e IDE, las fuentes y los modelos de salida.

Estos son datos públicos reales de fuentes oficiales. Las fuentes, los filtros y las condiciones de uso acompañan los archivos.

La guía describe cinco casos. Sus cinco paquetes de IA, encargos, esquemas y fuentes enlazadas se incluyen en ia/; no necesitas la guía web para abrirlos.

El inventario tiene diez referencias. Se incluyen tres PDF de NASA; los demás se consultan desde los enlaces oficiales. La IA genera la matriz de evidencia. No interpretes un documento registrado como documento leído; comprueba las páginas de las citas que vas a comunicar.
